package com.example.animale.Fracments

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.animale.R

class SelectedAnimal : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.animal_full)

    }

}