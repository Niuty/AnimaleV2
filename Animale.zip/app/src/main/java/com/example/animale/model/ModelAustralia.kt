package com.example.animale.model

data class ModelAustralia (val name: String, val continent: String): Entertainment(Type.AnimalAustalia)