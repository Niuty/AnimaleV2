package com.example.animale.model

data class ModelAmerica (val name: String, val continent: String): Entertainment(Type.AnimalAmerica)
