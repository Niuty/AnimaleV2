package com.example.animale.Fracments;

import androidx.fragment.app.Fragment;

public class FragmentAnimal extends Fragment {



}
