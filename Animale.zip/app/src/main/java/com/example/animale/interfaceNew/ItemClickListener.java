package com.example.animale.interfaceNew;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int position);
}
