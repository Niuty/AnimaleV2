package com.example.animale.model

data class ModelEuropa (val name: String, val continent: String): Entertainment(Type.AnimalEuropa)