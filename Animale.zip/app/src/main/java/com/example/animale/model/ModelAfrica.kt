package com.example.animale.model

data class ModelAfrica (val name: String, val continent: String): Entertainment(Type.AnimalAfrica)