package com.example.animale.model

data class ModelAsia (val name: String, val continent: String): Entertainment(Type.AnimalAsia)
