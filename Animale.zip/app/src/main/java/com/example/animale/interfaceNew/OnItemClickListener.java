package com.example.animale.interfaceNew;

import android.view.View;

public interface OnItemClickListener {
    public void onClick(View view, int position);
}

